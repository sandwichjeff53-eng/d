# Deploying to Vercel

This project is built with TanStack Start and Convex, and is ready for deployment to Vercel.

## Prerequisites

1.  A [Convex](https://www.convex.dev/) account and a project.
2.  A [Vercel](https://vercel.com/) account.

## Step 1: Convex Deployment Key

To allow Vercel to build and deploy your Convex functions, you need a deployment key.

1.  Go to your Convex dashboard.
2.  Navigate to **Settings** > **Deployment Keys**.
3.  Generate a new key for your production environment.
4.  Copy this key; you'll use it as `CONVEX_DEPLOY_KEY` in Vercel.

## Step 2: Deploy to Vercel

1.  Push your code to a GitHub/GitLab/Bitbucket repository.
2.  Import the project into Vercel.
3.  Vercel should automatically detect the framework as **TanStack Start**.
4.  In the **Environment Variables** section, add:
    *   `VITE_CONVEX_URL`: Your production Convex URL (found in the Convex dashboard).
    *   `CONVEX_DEPLOY_KEY`: The key you copied in Step 1.
5.  Click **Deploy**.

## Deployment Scripts

The `build` script in `package.json` is configured to run Convex codegen before the Vite build:

```json
"build": "npm run codegen && vite build && tsc --noEmit"
```

If you want Vercel to also deploy your Convex functions (schema and function code) on every push, you can update the build command in the Vercel dashboard to:

```bash
npx convex deploy --cmd 'npm run codegen && vite build && tsc --noEmit'
```

This ensures your backend and frontend are always in sync.
