import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  contact_submissions: defineTable({
    name: v.string(),
    email: v.string(),
    subject: v.string(),
    message: v.string(),
  }),
  menu_items: defineTable({
    name: v.string(),
    description: v.string(),
    price: v.string(),
    category: v.string(), // e.g., "Appetizers", "Burgers"
    isAvailable: v.boolean(),
  }).index("by_category_and_available", ["category", "isAvailable"]),
});
