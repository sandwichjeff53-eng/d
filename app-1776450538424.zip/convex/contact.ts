import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const submit = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    subject: v.string(),
    message: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    await ctx.db.insert("contact_submissions", {
      name: args.name,
      email: args.email,
      subject: args.subject,
      message: args.message,
    });
    return null;
  },
});
