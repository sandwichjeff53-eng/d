import { query } from "./_generated/server";
import { v } from "convex/values";

export const getByCategory = query({
  args: { category: v.string() },
  returns: v.array(v.object({
    _id: v.id("menu_items"),
    _creationTime: v.number(),
    name: v.string(),
    description: v.string(),
    price: v.string(),
    category: v.string(),
    isAvailable: v.boolean(),
  })),
  handler: async (ctx, args) => {
    return await ctx.db
      .query("menu_items")
      .withIndex("by_category_and_available", (q) => 
        q.eq("category", args.category).eq("isAvailable", true)
      )
      .collect();
  },
});
