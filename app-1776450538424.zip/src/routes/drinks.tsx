import { createFileRoute } from '@tanstack/react-router'
import { Footer } from '~/components/Footer'
import { Navbar } from '~/components/Navbar'

export const Route = createFileRoute('/drinks')({
  component: DrinksPage,
})

function DrinksPage() {
  const sections = [
    {
      title: "Beers on Tap",
      subtitle: "Ask about our rotations!",
      items: [
        "Yuengling",
        "Yuengling Flight",
        "Angry Orchard",
        "Budweiser",
        "Bud Select",
        "Blue Moon Belgian White",
        "Guinness",
        "Leinenkugel Seasonal",
        "Sam Adams Seasonal",
        "Shiner Bock",
        "Schlafly Pale",
        "Urban Chestnut Zwickle"
      ]
    },
    {
      title: "Bottled Beer",
      items: [
        "312",
        "Boulevard Wheat",
        "Bud Light Lime",
        "Budweiser",
        "Bud Light",
        "Bud Select",
        "Busch",
        "Busch Light",
        "Coors Light",
        "Corona",
        "Fat Tire",
        "Heineken",
        "Killians",
        "Michelob Ultra",
        "Michelob Golden Light",
        "Miller Lite",
        "Modelo",
        "Natural Light",
        "New Castle",
        "O’Douls",
        "Schlafly Pale Ale",
        "Stag",
        "Stella",
        "Vodka Lemonades/Teas"
      ]
    },
    {
      title: "Red Wines",
      items: [
        "Woodbridge Merlot (California)",
        "Taman Malbec (Columbia Valley, Washington)",
        "Woodbridge Cabernet (California)",
        "Tribute Cabernet Sauvignon",
        "Jacob’s Creek Cabernet (Australia)",
        "Woodbridge Pinot Noir (Chile)"
      ]
    },
    {
      title: "White Wines",
      items: [
        "Woodbridge Chardonnay (California)",
        "Jacobs Creek Chardonnay (Australia)",
        "Woodbridge White Zinfandel (California)",
        "Woodbridge Pinot Grigio (Chile)",
        "Schmitt Sohne Riesling (Germany)",
        "Woodbridge Sauvignon Blanc (Casablanca Valley, Chile)",
        "Fish Eye Mascato (Australia)"
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-haus-cream">
      <Navbar activePage="drinks" />

      {/* Hero */}
      <header className="relative bg-haus-brown text-white py-20 md:py-32 px-6 text-center overflow-hidden">
        <img 
          src="https://media-cdn.tripadvisor.com/media/photo-o/06/28/1a/2f/pacific-brew-haus-bar.jpg" 
          alt="Pacific Brew Haus Bar" 
          className="absolute inset-0 w-full h-full object-cover opacity-40 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-haus-brown/40 to-haus-brown/80" />
        <div className="relative z-10">
          <h1 className="text-4xl md:text-8xl font-black mb-6 md:mb-8 leading-none tracking-tighter uppercase">Beer & Wine</h1>
          <p className="text-haus-gold uppercase tracking-[0.2em] md:tracking-[0.4em] font-bold text-[10px] md:text-sm max-w-2xl mx-auto">
            Cold Brews & Fine Vintages
          </p>
        </div>
      </header>

      {/* Drink List */}
      <main className="py-16 md:py-24 px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-x-20 gap-y-20 md:gap-y-32">
          {sections.map((section, idx) => (
            <section key={idx}>
              <div className="mb-8 md:mb-12">
                <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tighter border-b-4 border-haus-gold inline-block mb-3 md:mb-4 text-haus-brown leading-none">
                  {section.title}
                </h2>
                {section.subtitle && (
                  <p className="text-haus-red font-bold text-[10px] md:text-xs uppercase tracking-widest mt-1 md:mt-2">{section.subtitle}</p>
                )}
              </div>
              <ul className="space-y-4 md:space-y-4">
                {section.items.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 md:gap-4 text-haus-brown group cursor-default">
                    <span className="w-1.5 h-1.5 bg-haus-red rounded-full flex-shrink-0 group-hover:scale-150 transition-transform" />
                    <span className="text-base md:text-lg font-black uppercase tracking-tight group-hover:text-haus-red transition-colors">{item}</span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        {/* Note Section */}
        <div className="mt-32 p-12 bg-white border border-haus-brown/10 text-center shadow-2xl relative">
          <p className="text-haus-brown/60 text-sm font-bold uppercase tracking-[0.2em] italic">
            "Ask your server about our seasonal rotations and daily drink specials."
          </p>
        </div>
      </main>

      <Footer />
    </div>
  )
}
