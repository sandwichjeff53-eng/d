import { createFileRoute, Link } from '@tanstack/react-router'
import { Footer } from '~/components/Footer'
import { Navbar } from '~/components/Navbar'

export const Route = createFileRoute('/menu')({
  component: MenuPage,
})

function MenuPage() {
  const categories = [
    {
      title: "Appetizers",
      items: [
        { name: "Jumbo Wings", description: "Tossed in your choice of Buffalo Bourbon, Hot, Hot Honey, Tangy Mild, Guinness BBQ, Lemon Pepper, Garlic Parmesan or Dry Rub.", price: "Dozen $18 | Two Dozen $35" },
        { name: "Loaded Tater Tots", description: "Tots topped with beer cheese sauce, bacon and scallions, served with sour cream. Add Buffalo chicken for $6.", price: "$11" },
        { name: "Toasted Raviolis", description: "Ravioli handmade in St. Louis by Nonnas and served with marinara.", price: "$10" },
        { name: "Potato Skins", description: "Skins covered with melted Monterey Jack cheese blend, bacon and scallions with a side of sour cream.", price: "$11" },
        { name: "Onion Rings", description: "Breaded onions served with a house-made chipotle sauce.", price: "$10" },
        { name: "Bavarian Pretzel", description: "Fried and served with beer cheese and parmesan.", price: "$9" },
        { name: "Fried Pickles", description: "Battered and fried pickle spears served with your choice of sauce.", price: "$10" },
        { name: "Reuben Bites", description: "Hand-rolled and breaded corned beef bites, Swiss cheese, cream cheese and sauerkraut, fried and served with 1000 Island.", price: "$12" },
        { name: "Chicken Strips", description: "Hand-breaded and fried to a golden brown, served with your choice of sauce. Try them tossed in a wing sauce for $1.", price: "$11" },
        { name: "Brew Bites", description: "Bite-sized pieces of hand-breaded whitefish served with house-made tomato tartar sauce.", price: "$12" },
        { name: "Flash Fried Spinach", description: "Lightly topped with grated parmesan and served with lemon wedge.", price: "$10" },
        { name: "Irish Nachos", description: "House chips topped with beer cheese sauce, chopped corned beef and a side of salsa.", price: "$12" },
      ]
    },
    {
      title: "Soup and Salad",
      subtitle: "Add to salad: Grilled chicken $6 | Steak $9 | Salmon $10",
      items: [
        { name: "Loaded Potato Soup", description: "", price: "Cup $4 | Bowl $6" },
        { name: "Brew Mix Salad", description: "Fresh lettuce blend topped with red onions, tomatoes, shredded cheese and croutons.", price: "Side $6 | Dinner $9" },
        { name: "Caesar Salad", description: "Fresh lettuce blend topped with parmesan cheese and croutons with caesar dressing.", price: "Side $6 | Dinner $9" },
        { name: "Cobb Salad", description: "Fresh lettuce blend topped with chicken, tomatoes, black olives, bacon, boiled egg and bleu cheese crumbles.", price: "$16" },
        { name: "Harvest Salad", description: "Fresh lettuce blend topped with dried cranberries, pecans, bacon, red onion, bleu cheese and raspberry vinaigrette.", price: "$14" },
        { name: "Irish Chef Salad", description: "Fresh lettuce blend topped with corned beef, smoked turkey, bacon, Monterey Jack cheese, tomatoes and boiled egg.", price: "$16" },
      ],
      footer: "Dressings: 1000 Island, Honey Mustard, Raspberry Vinaigrette, Balsamic Vinaigrette, Bleu Cheese, Golden Italian, Feta Cheese Vinaigrette, Homemade Ranch"
    },
    {
      title: "Sandwiches and Wraps",
      subtitle: "Served with chips, fries or tater tots. Substitute sweet potato fries +$2 | Onion rings +$2",
      items: [
        { name: "Chicken Breast", description: "Marinated and grilled chicken breast topped with Swiss cheese, bacon, house-made spread, lettuce and tomato on toasted sourdough.", price: "$12" },
        { name: "Buffalo Chicken Wrap", description: "Grilled chicken tossed in house hot sauce, pepper jack cheese, lettuce, tomato and ranch in a spinach wrap.", price: "$12" },
        { name: "Chicken Salad", description: "House-made chicken salad with dried cranberries and green onion, topped with lettuce and tomato on toasted sourdough.", price: "$12" },
        { name: "Haus Philly Sandwich", description: "Choice of grilled chicken or steak topped with grilled onions and peppers with provolone on a hoagie.", price: "$13" },
        { name: "French Dip", description: "Thin sliced roast beef topped with Swiss cheese on a hoagie with au jus.", price: "$12" },
        { name: "Fish Sandwich", description: "Hand-breaded fried fish topped with American cheese, lettuce and tomato on a hoagie roll with house tartar.", price: "$11" },
        { name: "Reuben", description: "House-cooked corned beef with 1000 Island, sauerkraut and Swiss on grilled marble rye.", price: "$12" },
        { name: "Steak Sandwich", description: "7 oz hand-cut strip steak topped with your choice of cheese on a hoagie roll.", price: "$16" },
        { name: "Turkey Bacon Wrap", description: "Smoked turkey, Swiss cheese, bacon, lettuce, tomato and ranch in a grilled spinach wrap.", price: "$11" },
        { name: "Turkey Club", description: "Smoked turkey, Swiss cheese, bacon, lettuce, tomato and house spread on grilled sourdough.", price: "$11" },
        { name: "Brew BLT", description: "Crispy bacon with lettuce, tomato and house-made spread on grilled sourdough.", price: "$12" },
      ]
    },
    {
      title: "Burgers",
      subtitle: "All burgers are fresh, never frozen 8 oz patties served with chips, fries or tater tots. Substitute sweet potato fries +$2 | Onion rings +$2",
      items: [
        { name: "Classic Burger", description: "Lettuce, tomato, onion, pickle.", price: "$11" },
        { name: "Cheeseburger", description: "Your choice of cheese.", price: "$12" },
        { name: "Bacon Cheeseburger", description: "Topped with crispy bacon and your choice of cheese.", price: "$13" },
        { name: "Mushroom Swiss Burger", description: "Sautéed mushrooms and Swiss cheese.", price: "$13" },
        { name: "BBQ Burger", description: "Topped with bacon, cheddar cheese and BBQ sauce.", price: "$13" },
        { name: "Patty Melt", description: "Grilled onions and Swiss cheese on grilled marble rye.", price: "$12" },
      ]
    },
    {
      title: "Entrées",
      subtitle: "Served with your choice of side",
      items: [
        { name: "Fish & Chips", description: "Hand-breaded cod fried golden brown, served with fries and tartar sauce.", price: "$15" },
        { name: "Chicken Tenders Dinner", description: "Hand-breaded chicken tenders served with fries and your choice of sauce.", price: "$14" },
        { name: "Steak Dinner", description: "Hand-cut strip steak cooked to order, served with choice of side.", price: "$20" },
        { name: "Salmon Dinner", description: "Grilled salmon served with choice of side.", price: "$18" },
      ]
    },
    {
      title: "Sides",
      items: [
        { name: "French Fries", description: "", price: "$4" },
        { name: "Tater Tots", description: "", price: "$4" },
        { name: "Sweet Potato Fries", description: "", price: "$5" },
        { name: "Onion Rings", description: "", price: "$5" },
        { name: "Side Salad", description: "", price: "$5" },
      ]
    },
    {
      title: "Kids Menu",
      subtitle: "Served with fries",
      items: [
        { name: "Kids Burger", description: "", price: "$7" },
        { name: "Grilled Cheese", description: "", price: "$6" },
        { name: "Chicken Tenders", description: "", price: "$7" },
      ]
    },
    {
      title: "Desserts & Drinks",
      items: [
        { name: "Chocolate Cake", description: "", price: "$6" },
        { name: "Cheesecake", description: "", price: "$6" },
        { name: "Soft Drinks", description: "", price: "$3" },
        { name: "Iced Tea", description: "", price: "$3" },
        { name: "Lemonade", description: "", price: "$3" },
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-haus-cream">
      <Navbar activePage="menu" />

      <header className="bg-haus-brown text-white py-16 md:py-20 px-6 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-black mb-4 uppercase tracking-tighter leading-none">The Haus Menu</h1>
        <p className="text-haus-gold tracking-[0.2em] md:tracking-[0.3em] uppercase font-bold text-[10px] md:text-sm">Authentic Food | Historic Setting</p>
      </header>

      <main className="max-w-6xl mx-auto py-12 md:py-20 px-6">
        <div className="grid md:grid-cols-2 gap-x-12 md:gap-x-20 gap-y-16 md:gap-y-24">
          {categories.map((cat, idx) => (
            <section key={idx}>
              <div className="mb-8 md:mb-10">
                <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tighter border-b-4 border-haus-red inline-block mb-3 md:mb-4 text-haus-brown">
                  {cat.title}
                </h2>
                {cat.subtitle && (
                  <p className="text-haus-red font-bold text-[10px] md:text-xs uppercase tracking-widest mt-1 md:mt-2">{cat.subtitle}</p>
                )}
              </div>
              
              <div className="space-y-8 md:space-y-10">
                {cat.items.map((item, i) => (
                  <div key={i} className="group text-haus-brown">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-baseline mb-2 gap-1 sm:gap-4">
                      <h3 className="text-lg md:text-xl font-black group-hover:text-haus-red transition-colors uppercase tracking-tight">{item.name}</h3>
                      <div className="flex-1 border-b border-haus-brown/10 border-dotted mb-1.5 hidden md:block"></div>
                      <span className="font-bold text-haus-brown/80 text-base md:text-lg whitespace-nowrap">{item.price}</span>
                    </div>
                    {item.description && (
                      <p className="text-haus-brown/70 text-xs md:text-sm italic leading-relaxed font-medium">{item.description}</p>
                    )}
                  </div>
                ))}
              </div>

              {cat.footer && (
                <div className="mt-8 p-4 bg-haus-brown/5 rounded border-l-4 border-haus-gold">
                  <p className="text-xs font-bold text-haus-brown/60 uppercase tracking-wide leading-relaxed">
                    {cat.footer}
                  </p>
                </div>
              )}
            </section>
          ))}
        </div>

        <div className="mt-20 md:mt-32 p-8 md:p-16 bg-haus-brown text-white text-center rounded-sm shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none select-none">
            <div className="text-[10rem] md:text-[15rem] font-black uppercase leading-none tracking-tighter absolute -left-5 md:-left-10 -top-5 md:-top-10">DRINK</div>
          </div>
          <div className="relative z-10">
            <h2 className="text-xl md:text-3xl text-haus-gold mb-6 font-black uppercase tracking-[0.2em]">CRAFT SELECTION</h2>
            <p className="mb-8 md:mb-10 opacity-80 max-w-2xl mx-auto text-base md:text-lg font-medium leading-relaxed italic">
              "We take pride in our rotating selection of local craft beers and fine wines. Ask your server about our current draft list!"
            </p>
            <div className="flex flex-wrap justify-center gap-4 md:gap-6">
              <Link to="/drinks" className="px-6 md:px-8 py-3 border-2 border-white/20 rounded-full text-[10px] md:text-xs font-black tracking-[0.2em] uppercase hover:bg-white hover:text-haus-brown transition-colors">Local Drafts</Link>
              <Link to="/drinks" className="px-6 md:px-8 py-3 border-2 border-white/20 rounded-full text-[10px] md:text-xs font-black tracking-[0.2em] uppercase hover:bg-white hover:text-haus-brown transition-colors">Fine Wine</Link>
              <Link to="/drinks" className="px-6 md:px-8 py-3 border-2 border-white/20 rounded-full text-[10px] md:text-xs font-black tracking-[0.2em] uppercase hover:bg-white hover:text-haus-brown transition-colors">Bottle Beer</Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
