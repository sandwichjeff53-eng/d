import { createFileRoute } from '@tanstack/react-router'
import { Footer } from '~/components/Footer'
import { Navbar } from '~/components/Navbar'

export const Route = createFileRoute('/catering')({
  component: CateringPage,
})

function CateringPage() {
  const cateringPackages = [
    {
      title: "The Opera House Platter",
      price: "Inquire for Pricing",
      items: ["Assorted Hand-Cut Steaks", "Roasted Seasonal Vegetables", "Garlic Mashed Potatoes", "Haus Salad"],
      description: "Our premier package designed for grand celebrations at the historic Opera House."
    },
    {
      title: "Brick Oven Pizza Bar",
      price: "Starting at $18/person",
      items: ["Unlimited Specialty Pizzas", "Choice of 3 Toppings", "Haus Wings", "Caesar Salad"],
      description: "A fun, interactive fire-kissed pizza experience for casual gatherings."
    },
    {
      title: "Haus Favorites Buffet",
      price: "Starting at $22/person",
      items: ["Mini Brew Bites", "Chicken Salad Sliders", "Sweet Potato Fries", "Fresh Fruit Medley"],
      description: "The perfect mix of our most popular starters and light favorites."
    }
  ]

  return (
    <div className="min-h-screen bg-haus-cream">
      <Navbar activePage="catering" />

      {/* Hero */}
      <header className="relative bg-haus-brown text-white py-20 md:py-32 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-haus-brown" />
        <div className="relative z-10">
          <h1 className="text-4xl md:text-8xl font-black mb-6 md:mb-8 leading-none tracking-tighter uppercase">Haus Catering</h1>
          <p className="text-haus-gold uppercase tracking-[0.2em] md:tracking-[0.4em] font-bold text-[10px] md:text-sm max-w-2xl mx-auto">
            Elevating events at the Opera House & Beyond
          </p>
        </div>
      </header>

      {/* Content */}
      <section className="py-16 md:py-24 px-6 max-w-7xl mx-auto">
        <div className="max-w-4xl mx-auto text-center mb-16 md:mb-28">
          <h2 className="text-3xl md:text-6xl font-black tracking-tighter uppercase leading-none mb-8 md:mb-10 text-haus-brown">Your Vision. <br />Our Hospitality.</h2>
          <p className="text-lg md:text-xl text-haus-brown/80 leading-relaxed font-medium mb-6 md:mb-8">
            Whether you're hosting a wedding at the Opera House or a corporate gathering downtown, Pacific Brew Haus brings the kitchen to you. 
          </p>
          <p className="text-lg md:text-xl text-haus-brown/80 leading-relaxed font-medium">
            We specialize in full-service onsite catering, providing everything from our signature hand-cut steaks to our fire-kissed brick oven pizzas.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-12 mb-20 md:mb-32">
          {cateringPackages.map((pkg, i) => (
            <div key={i} className="bg-white border-t-8 border-haus-gold p-8 md:p-12 shadow-2xl flex flex-col hover:-translate-y-2 transition-transform duration-300">
              <h3 className="text-2xl md:text-3xl font-black mb-4 uppercase tracking-tighter leading-none text-haus-brown">{pkg.title}</h3>
              <p className="text-haus-red font-black text-[10px] md:text-xs mb-6 md:mb-8 uppercase tracking-[0.2em]">{pkg.price}</p>
              <p className="text-haus-brown/70 mb-8 md:mb-10 text-sm leading-relaxed italic font-medium">{pkg.description}</p>
              <ul className="space-y-4 mb-8 md:mb-12 flex-1">
                {pkg.items.map((item, j) => (
                  <li key={j} className="text-xs md:text-sm font-bold uppercase tracking-wide flex items-center gap-3 md:gap-4 text-haus-brown/80">
                    <span className="w-2 h-2 bg-haus-red rounded-full flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="bg-white border border-haus-brown/10 p-10 md:p-16 text-center max-w-4xl mx-auto shadow-sm rounded-sm">
          <h2 className="text-3xl md:text-4xl font-black mb-6 uppercase tracking-tighter leading-none text-haus-brown">Start Planning Your Event</h2>
          <p className="text-haus-brown/70 mb-10 md:mb-12 text-base md:text-lg font-medium max-w-2xl mx-auto">
            Tell us more about your event and we'll craft a custom menu tailored to your guests.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center">
            <a href="mailto:pacificbrewhaus@gmail.com" className="bg-haus-brown text-white px-10 md:px-12 py-4 md:py-5 uppercase text-[11px] font-black tracking-[0.2em] hover:bg-haus-red transition-colors shadow-lg">
              Email Our Coordinator
            </a>
            <a href="tel:6362572650" className="border-2 border-haus-brown text-haus-brown px-10 md:px-12 py-4 md:py-5 uppercase text-[11px] font-black tracking-[0.2em] hover:bg-haus-brown hover:text-white transition-all shadow-md">
              Call (636) 257-2650
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
