import { createFileRoute, Link } from '@tanstack/react-router'
import { Footer } from '~/components/Footer'
import { Navbar } from '~/components/Navbar'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  return (
    <div className="min-h-screen bg-haus-cream text-haus-brown">
      {/* Top Banner */}
      <div className="bg-haus-red text-white py-2.5 px-4 text-center text-[10px] font-bold uppercase tracking-[0.25em] z-[60] relative">
        NOW HIRING: KITCHEN STAFF & SERVERS. <a href="mailto:pacificbrewhaus@gmail.com" className="underline hover:text-haus-gold transition-colors ml-2">APPLY NOW</a>
      </div>

      <Navbar activePage="home" />

      {/* Hero Section */}
      <section className="relative h-[70vh] md:h-[80vh] flex items-center justify-center overflow-hidden bg-haus-brown">
        <img 
          src="https://scontent-sea5-1.xx.fbcdn.net/v/t39.30808-6/622385262_1544470957499401_4155185399668519965_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=110&ccb=1-7&_nc_sid=2a1932&_nc_ohc=Wl_HRMSMbqMQ7kNvwFAQjJd&_nc_oc=AdqnaV7VtZPGdjGTH8T5L6NFijcrsyKSMeihiSwLzFwq5rDwvSDN_Ix9jVr0mVY4E94&_nc_zt=23&_nc_ht=scontent-sea5-1.xx&_nc_gid=DHWe2baT2IXcIsYizpqwog&_nc_ss=7a389&oh=00_Af3ZztuaR9fX9VozJrtl5GLOUwXbM-e6atdosVTTauoeNg&oe=69E7BA38" 
          alt="Pacific Brew Haus Hero" 
          className="absolute inset-0 w-full h-full object-cover opacity-60 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-haus-brown/60" />
        <div className="relative z-10 text-center px-6 max-w-5xl">
          <h1 className="text-5xl sm:text-7xl md:text-9xl font-black mb-6 md:mb-8 leading-none text-white tracking-tighter drop-shadow-2xl uppercase">
            A Legacy <br className="hidden md:block" /> Built in Brick
          </h1>
          <p className="text-sm md:text-2xl font-bold tracking-[0.4em] uppercase text-haus-gold drop-shadow-lg">
            Est. 2013 | Pacific, Missouri
          </p>
        </div>
      </section>

      {/* Intro / CTA */}
      <section className="py-20 md:py-28 px-6 md:px-12 bg-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-6xl mb-10 font-black tracking-tighter uppercase leading-none">Authentic Hospitality.</h2>
          <p className="text-lg md:text-xl text-haus-brown/80 leading-relaxed font-medium mb-10 md:mb-12 max-w-3xl mx-auto">
            Welcome to Pacific Brew Haus. Located in the heart of downtown Pacific, we offer a unique dining experience in the historic McHugh-Dailey building. Whether you're here for our fire-kissed pizzas, hand-cut steaks, or cold craft beer, you're family at the Haus.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 md:gap-6">
            <Link to="/menu" className="inline-block bg-haus-brown text-white px-10 md:px-12 py-4 md:py-5 uppercase text-[11px] font-black tracking-[0.2em] hover:bg-haus-red transition-all shadow-xl hover:-translate-y-1 active:translate-y-0">
              View Full Menu
            </Link>
            <Link to="/catering" className="inline-block border-2 border-haus-brown text-haus-brown px-10 md:px-12 py-4 md:py-5 uppercase text-[11px] font-black tracking-[0.2em] hover:bg-haus-brown hover:text-white transition-all shadow-lg hover:-translate-y-1 active:translate-y-0">
              Catering Services
            </Link>
          </div>
        </div>
      </section>

      {/* Beer Tap Gallery */}
      <section className="bg-haus-cream py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black uppercase tracking-tight mb-2">Cold Brews on Tap</h2>
            <div className="w-20 h-1 bg-haus-red mx-auto"></div>
          </div>
          <div className="relative group">
            <div className="absolute -inset-1 bg-haus-gold opacity-20 group-hover:opacity-40 transition-opacity blur rounded-sm"></div>
            <div className="relative bg-haus-brown rounded-sm overflow-hidden shadow-2xl border-4 border-haus-gold/30 group-hover:border-haus-gold/60 transition-colors">
              <img 
                src="https://static.wixstatic.com/media/ce8eb8_0ba2310c3aa019355e8b7c3b1f84307d.jpg/v1/fill/w_978,h_396,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/ce8eb8_0ba2310c3aa019355e8b7c3b1f84307d.jpg" 
                alt="Pacific Brew Haus Interior" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* History Section */}
      <section id="history" className="py-32 px-6 bg-haus-brown text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none select-none">
           <div className="text-[10rem] md:text-[20rem] font-black uppercase leading-none tracking-tighter absolute -left-10 md:-left-20 -top-10 md:-top-20">HAUS</div>
        </div>
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-7xl mb-10 font-black leading-none uppercase tracking-tighter">History Meets Hospitality</h2>
          <p className="text-xl md:text-2xl italic text-haus-gold mb-12 md:mb-16 opacity-90 font-light max-w-3xl mx-auto">
            "Standing strong since 2013, we continue the story of the McHugh-Dailey Building."
          </p>
          <div className="grid md:grid-cols-3 gap-12 md:gap-16 text-left">
            <div className="group">
              <h3 className="text-haus-gold text-sm font-black tracking-[0.2em] mb-6 uppercase pb-2 border-b border-white/10">The Building</h3>
              <p className="text-base text-white/70 leading-relaxed font-medium">Built in the late 1800s, the McHugh-Dailey building has been a cornerstone of Pacific commerce for over a century.</p>
            </div>
            <div className="group">
              <h3 className="text-haus-gold text-sm font-black tracking-[0.2em] mb-6 uppercase pb-2 border-b border-white/10">The Mission</h3>
              <p className="text-base text-white/70 leading-relaxed font-medium">To provide a gathering place for the community that honors our town's rich history while serving quality food and drink.</p>
            </div>
            <div className="group">
              <h3 className="text-haus-gold text-sm font-black tracking-[0.2em] mb-6 uppercase pb-2 border-b border-white/10">The Experience</h3>
              <p className="text-base text-white/70 leading-relaxed font-medium">Rustic charm meets modern service. We take pride in every pizza pulled from our ovens and every pint poured.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Visit / Updates Section */}
      <section id="visit" className="py-20 md:py-28 px-4 md:px-12 bg-haus-cream">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 md:gap-20">
          <div>
            <h2 className="text-3xl md:text-4xl font-black mb-10 uppercase tracking-tighter leading-none px-2 md:px-0">Find the Haus</h2>
            <div className="grid sm:grid-cols-2 gap-8 md:gap-10 mb-10 md:mb-12 px-2 md:px-0">
              <div>
                <h3 className="text-haus-red text-xs font-black tracking-[0.2em] mb-3 uppercase">Address</h3>
                <p className="font-bold text-lg leading-snug">220 S 1st St.<br />Pacific, MO 63069</p>
              </div>
              <div>
                <h3 className="text-haus-red text-xs font-black tracking-[0.2em] mb-3 uppercase">Contact</h3>
                <p className="font-bold text-lg leading-snug">
                  <a href="tel:6362572650" className="hover:text-haus-red transition-colors">(636) 257-2650</a><br />
                  <a href="mailto:pacificbrewhaus@gmail.com" className="text-sm underline hover:text-haus-red transition-colors lowercase">pacificbrewhaus@gmail.com</a>
                </p>
              </div>
            </div>
            <div className="w-full h-[350px] md:h-[450px] bg-white rounded-sm overflow-hidden shadow-2xl border-4 border-white">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3121.728980838634!2d-90.7457017240742!3d38.48243687181512!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87d930263309a96b%3A0xe21a8d0113c6f849!2sPacific%20Brew%20Haus!5e0!3m2!1sen!2sus!4v1713340000000!5m2!1sen!2sus" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Pacific Brew Haus Location"
              />
            </div>
          </div>
          <div id="social">
            <h2 className="text-3xl md:text-4xl font-black mb-10 uppercase tracking-tighter leading-none px-2 md:px-0">Haus Updates</h2>
            <div className="bg-white rounded-sm shadow-2xl border-4 border-white h-[600px] md:h-[750px] overflow-hidden flex justify-center">
               <iframe 
                src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fpacificbrewhaus&tabs=timeline&width=340&height=750&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true" 
                width="340" 
                height="100%" 
                style={{ border: 'none', overflow: 'hidden' }} 
                scrolling="no" 
                frameBorder="0" 
                allowFullScreen={true} 
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                title="Facebook Feed"
                className="max-w-full"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
