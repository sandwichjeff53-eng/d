import { Link } from '@tanstack/react-router'
import { useState } from 'react'

interface NavLinkProps {
  to: string
  children: React.ReactNode
  active?: boolean
  onClick?: () => void
}

function NavLink({ to, children, active, onClick }: NavLinkProps) {
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`text-sm md:text-[10px] font-black uppercase tracking-[0.2em] transition-colors ${
        active ? 'text-haus-red' : 'text-haus-brown/70 hover:text-haus-red'
      }`}
    >
      {children}
    </Link>
  )
}

export function Navbar({ activePage }: { activePage?: string }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="border-b border-haus-brown/10 py-4 px-6 md:px-12 flex justify-between items-center bg-white sticky top-0 z-50 shadow-sm">
      <Link to="/" className="flex items-center gap-4 group">
        <div className="h-14 md:h-16 w-auto flex flex-col items-center justify-center leading-none text-center">
          <span className="text-[8px] md:text-[10px] font-black tracking-[0.4em] uppercase text-haus-brown/60 mb-0.5 md:mb-1">PACIFIC</span>
          <div className="h-10 md:h-12 w-auto bg-black flex items-center justify-center px-2 md:px-3 py-1 md:py-1.5 rounded shadow-lg group-hover:scale-105 transition-transform duration-300">
             <img 
              src="https://static.wixstatic.com/media/ce8eb8_28f82e30a28646a082ef21c2b7563d4f~mv2.png/v1/fill/w_374,h_384,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/PBH-logo.png" 
              alt="Pacific Brew Haus Logo" 
              className="h-full w-auto"
            />
          </div>
          <span className="text-[8px] md:text-[10px] font-black tracking-[0.2em] uppercase text-haus-brown/60 mt-0.5 md:mt-1">BREW HAUS</span>
        </div>
      </Link>

      {/* Desktop Menu */}
      <div className="hidden md:flex gap-8">
        <NavLink to="/" active={activePage === 'home'}>Home</NavLink>
        <NavLink to="/menu" active={activePage === 'menu'}>Menu</NavLink>
        <NavLink to="/drinks" active={activePage === 'drinks'}>Beer & Wine</NavLink>
        <NavLink to="/catering" active={activePage === 'catering'}>Catering</NavLink>
      </div>

      {/* Mobile Menu Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden flex flex-col gap-1.5 p-2"
        aria-label="Toggle Menu"
      >
        <div className={`w-6 h-0.5 bg-haus-brown transition-transform ${isOpen ? 'rotate-45 translate-y-2' : ''}`} />
        <div className={`w-6 h-0.5 bg-haus-brown transition-opacity ${isOpen ? 'opacity-0' : ''}`} />
        <div className={`w-6 h-0.5 bg-haus-brown transition-transform ${isOpen ? '-rotate-45 -translate-y-2' : ''}`} />
      </button>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 bg-white z-[60] flex flex-col items-center justify-center gap-8 transition-transform duration-300 md:hidden ${isOpen ? 'translate-y-0' : '-translate-y-full'}`}>
        <button 
          onClick={() => setIsOpen(false)}
          className="absolute top-6 right-6 p-4 text-haus-brown uppercase font-black text-xs tracking-widest"
        >
          Close
        </button>
        <NavLink to="/" active={activePage === 'home'} onClick={() => setIsOpen(false)}>Home</NavLink>
        <NavLink to="/menu" active={activePage === 'menu'} onClick={() => setIsOpen(false)}>Menu</NavLink>
        <NavLink to="/drinks" active={activePage === 'drinks'} onClick={() => setIsOpen(false)}>Beer & Wine</NavLink>
        <NavLink to="/catering" active={activePage === 'catering'} onClick={() => setIsOpen(false)}>Catering</NavLink>
        
        <div className="mt-8 pt-8 border-t border-haus-brown/10 w-48 text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-haus-brown/40 mb-4">Visit Us</p>
          <p className="text-xs font-bold uppercase mb-1">220 S 1st St.</p>
          <p className="text-xs font-bold uppercase">Pacific, MO 63069</p>
        </div>
      </div>
    </nav>
  )
}
