import { Link } from '@tanstack/react-router'

export function Footer() {
  return (
    <footer className="bg-haus-brown pt-32 pb-12 px-6 md:px-12 text-white border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-16 pb-24 border-b border-white/10 text-left">
          <div className="col-span-1 md:col-span-2">
            <h2 className="text-3xl text-white font-black tracking-tighter uppercase leading-none mb-8">PACIFIC BREW HAUS</h2>
            <p className="text-white/50 max-w-lg font-medium leading-relaxed text-lg italic mb-10">
              "Authentic hospitality in the heart of Pacific, MO. A legacy built on community and quality in the historic McHugh-Dailey Building."
            </p>
            <div className="flex gap-6">
              <a href="https://www.facebook.com/pacificbrewhaus" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-haus-red transition-colors group">
                <span className="text-xs font-black group-hover:scale-110 transition-transform">FB</span>
              </a>
              <a href="mailto:pacificbrewhaus@gmail.com" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-haus-red transition-colors group">
                <span className="text-xs font-black group-hover:scale-110 transition-transform">@</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-haus-gold text-xs font-black tracking-[0.2em] mb-8 uppercase">VISIT</h3>
            <ul className="space-y-4 text-sm font-bold tracking-wide text-white/60">
              <li className="hover:text-white transition-colors uppercase">220 S 1st St.</li>
              <li className="hover:text-white transition-colors uppercase">Pacific, MO 63069</li>
              <li className="text-haus-gold mt-6 hover:text-white transition-colors uppercase">
                <a href="tel:6362572650">(636) 257-2650</a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-haus-gold text-xs font-black tracking-[0.2em] mb-8 uppercase">HOURS</h3>
            <ul className="space-y-4 text-[11px] font-black tracking-widest text-white/40 uppercase">
              <li className="flex flex-col border-b border-white/5 pb-2">
                <div className="flex justify-between mb-1"><span>KITCHEN</span> <span className="text-white/70">MON-SUN 11AM-9PM</span></div>
                <div className="text-[9px] text-haus-gold font-bold italic">The Bar is open till 10PM on Fridays & Saturdays</div>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-white/20 text-[9px] font-bold uppercase tracking-[0.4em]">© 2025 PACIFIC BREW HAUS. CRAFTED BY CTO.NEW</p>
          <div className="flex gap-10 text-[9px] font-bold uppercase tracking-[0.4em] text-white/30">
            <Link to="/menu" className="hover:text-haus-gold transition-colors">Menu</Link>
            <Link to="/drinks" className="hover:text-haus-gold transition-colors">Beer & Wine</Link>
            <Link to="/catering" className="hover:text-haus-gold transition-colors">Catering</Link>
            <a href="#" className="hover:text-haus-gold transition-colors">Privacy</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
